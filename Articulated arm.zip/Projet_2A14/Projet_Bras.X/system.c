/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__XC16__)
    #include <xc.h>
#elif defined(__C30__)
    #if defined(__PIC24E__)
    	#include <p24Exxxx.h>
    #elif defined (__PIC24F__)||defined (__PIC24FK__)
	#include <p24Fxxxx.h>
    #elif defined(__PIC24H__)
	#include <p24Hxxxx.h>
    #endif
#endif

#include <stdint.h>          /* For uint32_t definition */
#include <stdbool.h>         /* For true/false definition */

#include "system.h"          /* variables/params used by system.c */

/******************************************************************************/
/* System Level Functions                                                     */
/*                                                                            */
/* Custom oscillator configuration funtions, reset source evaluation          */
/* functions, and other non-peripheral microcontroller initialization         */
/* functions get placed in system.c                                           */
/*                                                                            */
/******************************************************************************/

/* Refer to the device Family Reference Manual Oscillator section for
information about available oscillator configurations.  Typically
this would involve configuring the oscillator tuning register or clock
switching useing the compiler's __builtin_write_OSCCON functions.
Refer to the C Compiler for PIC24 MCUs and dsPIC DSCs User Guide in the
compiler installation directory /doc folder for documentation on the
__builtin functions. */

/* TODO Add clock switching code if appropriate.  An example stub is below.   */
void PWM_Change(char choice){
    
    switch(choice){
        /* Position global */  // Les pulses doivent �tre entre 5 et 10% de Duty cycle soit, entre 0.5 et 2.5 ms, soit 0x0210 et 0x0900
                                // On choisirat volontairement des valeur enter ces deux pour r�aliser les mouvements sans briser la m�canique du bras
        case 'V':
            CCP1RB = 0x035D;    //Moteur a 37.75�
            CCP4RB = 0x0588;    //Moteur a 90�
            CCP5RB = 0x0210;    //Moteur a 0�
            break;
        case 'D':
            CCP1RB = 0x02EE;    //Moteur a 22.5�    
            CCP4RB = 0x04AA;    //Moteur a 67.5�
            CCP5RB = 0x02EE;    //Moteur a 22.5�   
            break;
        case 'F':
            CCP1RB = 0x0210;    //Moteur a 0� 
            CCP4RB = 0x03CC;    //Moteur a 45�
            CCP5RB = 0x03CC;    //Moteur a 45�
            break;
        case 'B':
            CCP1RB = 0x0210;    //Moteur a 0�
            CCP4RB = 0x0210;    //Moteur a 0�
            CCP5RB = 0x0588;    //Moteur a 90�
            break;    
            
        /* Moteur  1 */ 
            
        case 'a':
            CCP1RB = 0x03CC;       //Moteur a 45�     
            break;
        case 'b':
            CCP1RB = 0x035D;       //Moteur a 37.75�   
            break;
        case 'c':
            CCP1RB = 0x02EE;       //Moteur a 22.5�   
            break;
        case 'd':
            CCP1RB = 0x027F;       //Moteur a 11.25�   
            break;
        case 'e':
            CCP1RB = 0x0210;       //Moteur a 0�    
            break;
            
        /* Moteur 2 */ 
            
        case 'k':
            CCP4RB = 0x0588;        //Moteur a 90�   
            break;
        case 'l':
            CCP4RB = 0x04AA;        //Moteur a 67.5� 
            break;    
        case 'm':
            CCP4RB = 0x03CC;        //Moteur a 45�   
            break; 
        case 'n':
            CCP4RB = 0x02EE;        //Moteur a 22.5�   
            break;
        case 'o':
            CCP4RB = 0x0210;        //Moteur a 0�   
            break; 
            
        /* Moteur 3 */
           
        case 'v':
            CCP5RB = 0x0588;        //Moteur a 90�
            break;
        case 'w':
            CCP5RB = 0x04AA;        //Moteur a 67.5�
            break;
        case 'x':
            CCP5RB = 0x03CC;        //Moteur a 45�
            break;
        case 'y':
            CCP5RB = 0x02EE;        //Moteur a 22.5�
            break;
        case 'z':
            CCP5RB = 0x0210;        //Moteur a 0�
            break;    
            
    
    
    }
    
}

