/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__XC16__)
    #include <xc.h>
#elif defined(__C30__)
    #if defined(__PIC24E__)
    	#include <p24Exxxx.h>
    #elif defined (__PIC24F__)||defined (__PIC24FK__)
	#include <p24Fxxxx.h>
    #elif defined(__PIC24H__)
	#include <p24Hxxxx.h>
    #endif
#endif

#include <stdint.h>          /* For uint32_t definition */
#include <stdbool.h>         /* For true/false definition */

#include "user.h"            /* variables/params used by user.c */

/******************************************************************************/
/* User Functions                                                             */
/******************************************************************************/

/* <Initialize variables in user.h and insert code for user algorithms.> */

/* TODO Initialize User Ports/Peripherals/Project here */

void clock_init(void){
    //DOC page 90
    //IRCF 8MHZ 
    //SCS Internal oscillator clock
    OSCCONbits.COSC = 0b000;
    OSCCONbits.NOSC = 0b000;
    
}

void CAN_init(void){
    
    AD1CON1bits.MODE12=0; //10 bit conversion
    AD1CON1bits.ASAM=1; //Sampling start just after the conversion is done
    AD1CON1bits.SSRC=0b0111; //Auto-conversion after Sampling
    AD1CON1bits.FORM=0; //Result is an integer
    
    AD1CON2bits.PVCFG = 0b00;           // Set voltage to AVdd
    AD1CON2bits.NVCFG0 = 0;         // Set voltage to AVss
    AD1CON2bits.ALTS=0; // Set to alternate between AN0 and AN9 ( not functionnal, set to 0))
    AD1CON2bits.BUFREGEN=1; //Result is always loaded in the same buffer determined by the channel converted
    
    AD1CON3bits.ADRC=0; //Conversion clock set to internal clock of AD Converter
    AD1CON3bits.SAMC=0b00001; // Sampling period

   //ADC1BUFF pour trouver les valeurs
    
    AD1CHS  = 0;  
    
    AD1CHSbits.CH0SA=0b00000;// Configure input channels,
    // S/H+ input is AN0 and AN9,
    // S/H- input is Vr- (AVss).
     
    AD1CON1bits.ADON=1;
    
    
}

void PWM_init(void){
    // Set MCCP operating mode PMW1
CCP1CON1Lbits.CCSEL = 0;      // Set MCCP operating mode (OC mode)
CCP1CON1Lbits.MOD = 0b0101;   // Set mode (Buffered Dual-Compare/PWM mode)
//Configure MCCP Timebase
CCP1CON1Lbits.TMR32 = 0;      // Set timebase width (16-bit)
CCP1CON1Lbits.TMRSYNC = 0;    // Set timebase synchronization (Synchronized)
CCP1CON1Lbits.CLKSEL = 0b000; // Set the clock source (Tcy)
CCP1CON1Lbits.TMRPS = 0b01;   // Set the clock pre-scaler (1:4)
CCP1CON1Hbits.TRIGEN = 0;     // Set Sync/Triggered mode (Synchronous)
CCP1CON1Hbits.SYNC = 0b00000; // Select Sync/Trigger source (Self-sync)
//Configure MCCP output for PWM signal
CCP1CON2Hbits.OCCEN = 1;      //Configure MCCP output for PWM signal
CCP1CON2Hbits.OCCEN = 1;// Enable desired output signals (OC1C)
CCP1CON3Hbits.OUTM = 0b000;   // Set advanced output modes (Standard output)
CCP1CON3Hbits.POLACE = 0;     //Configure output polarity (Active High)
CCP1TMRL = 0x0000;            //Initialize timer prior to enable module.
CCP1PRL = 0x4E20;             //Configure timebase period of 50Hz
CCP1RA = 0x0000;              // Set the rising edge compare value
CCP1RB = 0x0210;              // Set the falling edge compare value
CCP1CON1Lbits.CCPON = 1;      // Turn on MCCP modul

// Set SCCP operating mode PMW2
CCP4CON1Lbits.CCSEL = 0;      // Set MCCP operating mode (OC mode)
CCP4CON1Lbits.MOD = 0b0101;   // Set mode (Buffered Dual-Compare/PWM mode)
//Configure MCCP Timebase
CCP4CON1Lbits.TMR32 = 0;      // Set timebase width (16-bit)
CCP4CON1Lbits.TMRSYNC = 0;    // Set timebase synchronization (Synchronized)
CCP4CON1Lbits.CLKSEL = 0b000; // Set the clock source (Tcy)
CCP4CON1Lbits.TMRPS = 0b01;   // Set the clock pre-scaler (1:4)
CCP4CON1Hbits.TRIGEN = 0;     // Set Sync/Triggered mode (Synchronous)
CCP4CON1Hbits.SYNC = 0b00000; // Select Sync/Trigger source (Self-sync)
//Configure MCCP output for PWM signal
CCP4CON2Hbits.OCAEN = 1;  
CCP4CON3Hbits.POLACE = 0;     //Configure output polarity (Active High)
CCP4TMRL = 0x0000;            //Initialize timer prior to enable module.
CCP4PRL = 0x4E20;             //Configure timebase period of 50Hz
CCP4RA = 0x0000;              // Set the rising edge compare value
CCP4RB = 0x0210;              // Set the falling edge compare value
CCP4CON1Lbits.CCPON = 1;      // Turn on MCCP modul

// Set SCCP operating mode PMW3
CCP5CON1Lbits.CCSEL = 0;      // Set MCCP operating mode (OC mode)
CCP5CON1Lbits.MOD = 0b0101;   // Set mode (Buffered Dual-Compare/PWM mode)
//Configure MCCP Timebase
CCP5CON1Lbits.TMR32 = 0;      // Set timebase width (16-bit)
CCP5CON1Lbits.TMRSYNC = 0;    // Set timebase synchronization (Synchronized)
CCP5CON1Lbits.CLKSEL = 0b000; // Set the clock source (Tcy)
CCP5CON1Lbits.TMRPS = 0b01;   // Set the clock pre-scaler (1:4)
CCP5CON1Hbits.TRIGEN = 0;     // Set Sync/Triggered mode (Synchronous)
CCP5CON1Hbits.SYNC = 0b00000; // Select Sync/Trigger source (Self-sync)
//Configure MCCP output for PWM signal
CCP5CON2Hbits.OCAEN = 1;  
CCP5CON3Hbits.POLACE = 0;     //Configure output polarity (Active High)
CCP5TMRL = 0x0000;            //Initialize timer prior to enable module.
CCP5PRL = 0x4E20;             //Configure timebase period of 50Hz
CCP5RA = 0x0000;              // Set the rising edge compare value
CCP5RB = 0x0588;              // Set the falling edge compare value
CCP5CON1Lbits.CCPON = 1;      // Turn on MCCP modul
}

void gpio_init(void){
    //Port 2 et 26 en analogique
    TRISAbits.TRISA0=1; //Pin2 et 26 en entr�e
    TRISBbits.TRISB15=1;
    ANSAbits.ANSA0=1; // Pin2 en Anaologique
    ANSBbits.ANSB15=1; // Pin26 en Analogique
    
    //Port 4 et 5 en sortie et entr�e
    TRISBbits.TRISB0=0; //�Pin 4 et 5 en sortie et entr�e num�rique
    TRISBbits.TRISB1=1;
    ANSBbits.ANSB0=0;
    ANSBbits.ANSB1=0;
    
} 

void UART_init(void){
    
U2MODEbits.UARTEN=1; //Enable the UART pin and override TRIS et ANS
U2MODEbits.BRGH=0; //Enable baud rate to be low rate
U2MODEbits.PDSEL=0b00;
U2MODEbits.STSEL=0;

U2BRG=25; // set baud rate to 9615

U2STAbits.UTXEN=1; //Enable transfer on TX pin

IEC1bits.U2RXIE=1; // enable receive interrupt
IFS1bits.U2RXIF=0; //Flag a 0





    
}

