/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__XC16__)
    #include <xc.h>
#elif defined(__C30__)
    #if defined(__PIC24E__)
    	#include <p24Exxxx.h>
    #elif defined (__PIC24F__)||defined (__PIC24FK__)
	#include <p24Fxxxx.h>
    #elif defined(__PIC24H__)
	#include <p24Hxxxx.h>
    #endif
#endif

#include <stdint.h>        /* Includes uint16_t definition                    */
#include <stdbool.h>       /* Includes true/false definition                  */

#include "system.h"        /* System funct/params, like osc/peripheral config */
#include "user.h"          /* User funct/params, such as InitApp              */

/******************************************************************************/
/* Global Variable Declaration                                                */
/******************************************************************************/

/* i.e. uint16_t <variable_name>; */

/******************************************************************************/
/* Main Program                                                               */
/******************************************************************************/

#include <libpic30.h>

int CaptOrd=0; //Controle Ordinateur
char UartRcv; //Char de recep

void main(void){
    clock_init();
    gpio_init();
    PWM_init();
    CAN_init();
    UART_init();
    
    int PIN,RESCAPT1,RESCAPT2;
    PIN=2;
    
    while(1){
        
        if(CaptOrd==1){ //Si le contr�le Capteur est activ�
            
            if(AD1CON1bits.ADON==0){  //On d�marre  le CAN si cela n'as pas �t� fait
                AD1CON1bits.ADON=1;
            }
            
            while(AD1CON1bits.DONE==0){} //On attend la fin de la conversion du CAN
        
            if(PIN==2){  //On sauvegarde la valeur converti et on change de PIN pour la conversion
                RESCAPT1=ADC1BUF0;
                AD1CHSbits.CH0SA=0b01001;
                PIN=26;
            }
            else{
                RESCAPT2=ADC1BUF9;
                AD1CHSbits.CH0SA=0b00000;
                PIN=2;
            } 
       
            if((RESCAPT1>=130)&&(RESCAPT2>=130)){  //En fonction de la valeur des capteurs on enclenche un mouvement
                PWM_Change('V');
                
            }
            else if((RESCAPT1<=130)&&(RESCAPT2>=130)){
                PWM_Change('D');
                
            }
            else if((RESCAPT1>=130)&&(RESCAPT2<=130)){
                PWM_Change('F');
                
            }
            else if((RESCAPT1<=130)&&(RESCAPT2<=130)){
                PWM_Change('B');
                
            }
       
        }
        else if (CaptOrd==0){ //Si le contr�le ordinateur est activ�
            
            if(AD1CON1bits.ADON==1){ //On d�sactive le CAN si �a n'as pas �t� fait
                AD1CON1bits.ADON=0;
            }
            PWM_Change(UartRcv); //On bouge le bras en fonction du caract�re re�u
        }
        
    }
}
