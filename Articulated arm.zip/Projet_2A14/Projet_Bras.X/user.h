/******************************************************************************/
/* User Level #define Macros                                                  */
/******************************************************************************/

/* TODO Application specific user parameters used in user.c may go here */

/******************************************************************************/
/* User Function Prototypes                                                   */
/******************************************************************************/

/* TODO User level functions prototypes (i.e. InitApp) go here */

    void clock_init(void);
    void gpio_init(void);
    void PWM_init(void);
    void CAN_init(void);
    void UART_init(void);
