function varargout = RobotControlPanel(varargin)
% ROBOTCONTROLPANEL MATLAB code for RobotControlPanel.fig
%      ROBOTCONTROLPANEL, by itself, creates a new ROBOTCONTROLPANEL or raises the existing
%      singleton*.
%
%      H = ROBOTCONTROLPANEL returns the handle to a new ROBOTCONTROLPANEL or the handle to
%      the existing singleton*.
%
%      ROBOTCONTROLPANEL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ROBOTCONTROLPANEL.M with the given input arguments.
%
%      ROBOTCONTROLPANEL('Property','Value',...) creates a new ROBOTCONTROLPANEL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before RobotControlPanel_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to RobotControlPanel_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help RobotControlPanel

% Last Modified by GUIDE v2.5 16-May-2018 09:38:13

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @RobotControlPanel_OpeningFcn, ...
                   'gui_OutputFcn',  @RobotControlPanel_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before RobotControlPanel is made visible.
function RobotControlPanel_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to RobotControlPanel (see VARARGIN)

% Choose default command line output for RobotControlPanel
handles.output = hObject;
s=serial('COM13'); %Cr�ation port s�rie avec le nom et les caract�risque de la connexion
set(s,'BaudRate',9600);
set(s,'DataBits',8);
set(s,'StopBits',1);
fopen(s); %Ouverture du Port
handles.s=s; %Stockage de la variable pour les autre fonctions
guidata(hObject,handles);
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes RobotControlPanel wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = RobotControlPanel_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning out+9+9put args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;






% --- Executes on button press in ComputerButton.
function ComputerButton_Callback(hObject, eventdata, handles)
% hObject    handle to ComputerButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.ManualControl,'visible','on'); %On active le panneau des moteurs si on est en contr�le ordinateur
set(handles.ModeScreen,'String','Computer');
s=handles.s; %On R�cup�re le Port
fwrite(s,'OOOO'); %Passage du PIC en Ordinateur



% --- Executes on button press in SensorButton.
function SensorButton_Callback(hObject, eventdata, handles)
% hObject    handle to SensorButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.ManualControl,'visible','off'); %Cache le panneau de contr�le moteur en mode Capteur
set(handles.ModeScreen,'String','Sensor');
s=handles.s;%On R�cup�re le Port
fwrite(s,'CCCC'); %Passage du PIC en mode Capteur


% --- Executes on button press in LowerAngleM1.
function LowerAngleM1_Callback(hObject, eventdata, handles)
% hObject    handle to LowerAngleM1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Val=str2num(get(handles.MotorAngle1,'String')); %Fonctionnement du bouton
if(Val~=0)
Val=Val-11.25;
end
set(handles.MotorAngle1,'String',num2str(Val));


% --- Executes on button press in IncreaseAngleM1.
function IncreaseAngleM1_Callback(hObject, eventdata, handles)
% hObject    handle to IncreaseAngleM1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Val=str2num(get(handles.MotorAngle1,'String'));
if(Val~=45)
Val=Val+11.25;
end
set(handles.MotorAngle1,'String',num2str(Val));


% --- Executes on button press in LowerAngleM2.
function LowerAngleM2_Callback(hObject, eventdata, handles)
% hObject    handle to LowerAngleM2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Val=str2num(get(handles.MotorAngle2,'String'));
if(Val~=0)
Val=Val-22.5;
end
set(handles.MotorAngle2,'String',num2str(Val));


% --- Executes on button press in IncreaseAngleM2.
function IncreaseAngleM2_Callback(hObject, eventdata, handles)
% hObject    handle to IncreaseAngleM2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Val=str2num(get(handles.MotorAngle2,'String'));
if(Val~=90)
Val=Val+22.5;
end
set(handles.MotorAngle2,'String',num2str(Val));


% --- Executes on button press in LowerAngleM3.
function LowerAngleM3_Callback(hObject, eventdata, handles)
% hObject    handle to LowerAngleM3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Val=str2num(get(handles.MotorAngle3,'String'));
if(Val~=0)
Val=Val-22.5;
end
set(handles.MotorAngle3,'String',num2str(Val));


% --- Executes on button press in IncreaseAngleM3.
function IncreaseAngleM3_Callback(hObject, eventdata, handles)
% hObject    handle to IncreaseAngleM3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Val=str2num(get(handles.MotorAngle3,'String'));
if(Val~=90)
Val=Val+22.5;
end
set(handles.MotorAngle3,'String',num2str(Val));




% --- Executes on button press in SetPosition.
function SetPosition_Callback(hObject, eventdata, handles)
% hObject    handle to SetPosition (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ValM1=str2num(get(handles.MotorAngle1,'String'));
ValM2=str2num(get(handles.MotorAngle2,'String'));
ValM3=str2num(get(handles.MotorAngle3,'String'));

s=handles.s; %On R�cup�re le Port

%Suivant les valeurs d'angles affich� on envoie un caract�re en particulier

if(ValM1==0)
    fwrite(s,'eeee');
elseif(ValM1==11.25)
    fwrite(s,'dddd');
elseif(ValM1==22.5)
    fwrite(s,'cccc');
elseif(ValM1==33.75)
    fwrite(s,'bbbb');
elseif(ValM1==45)
    fwrite(s,'aaaa');
    
end

if(ValM2==0)
    fwrite(s,'oooo');
elseif(ValM2==22.5)
    fwrite(s,'nnnn');
elseif(ValM2==45)
    fwrite(s,'mmmm');
elseif(ValM2==67.5)
    fwrite(s,'llll');
elseif(ValM2==90)
    fwrite(s,'kkkk');
    
end

if(ValM3==0)
    fwrite(s,'vvvv');
elseif(ValM3==22.5)
    fwrite(s,'wwww');
elseif(ValM3==45)
    fwrite(s,'xxxx');
elseif(ValM3==67.5)
    fwrite(s,'yyyy');
elseif(ValM3==90)
    fwrite(s,'zzzz');
    
end






% --- Executes on button press in Position1.
function Position1_Callback(hObject, eventdata, handles)
% hObject    handle to Position1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
s=handles.s;%On R�cup�re le Port
fwrite(s,'BBBB');

% --- Executes on button press in Position2.
function Position2_Callback(hObject, eventdata, handles)
% hObject    handle to Position2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
s=handles.s;%On R�cup�re le Port
fwrite(s,'FFFF');

% --- Executes on button press in Position3.
function Position3_Callback(hObject, eventdata, handles)
% hObject    handle to Position3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
s=handles.s; %On R�cup�re le Port
fwrite(s,'DDDD');


% --- Executes on button press in Position4.
function Position4_Callback(hObject, eventdata, handles)
% hObject    handle to Position4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
s=handles.s; %On R�cup�re le Port
fwrite(s,'VVVV');

% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
s=handles.s; %On R�cup�re le Port
fclose(s); %On ferme le port
delete s; %On supprime le Port
% Hint: delete(hObject) closes the figure
delete(hObject);






